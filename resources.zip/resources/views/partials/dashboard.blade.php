@extends('layouts.admin')
@include('partials.sidebar')
@section('content')

@endsection