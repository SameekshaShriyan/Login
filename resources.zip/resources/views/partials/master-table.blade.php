<div class="card">
    <div class="card-body">
        <table class="table table-bordered table-striped">
            {{ $slot }}
        </table>
    </div>
</div>